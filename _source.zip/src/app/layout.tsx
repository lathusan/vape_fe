import type { Metadata, Viewport } from "next";
import { GeistSans } from "geist/font/sans";
import { GeistMono } from "geist/font/mono";
import "./globals.css";
import { StoreProvider } from "@/lib/store";
import { AgeGate } from "@/components/store/AgeGate";
import { BRAND } from "@/lib/data";

export const metadata: Metadata = {
  title: { default: `${BRAND.full} | UK vape store & wholesale`, template: `%s | ${BRAND.name}` },
  description: "Pod kits, e-liquids, nic salts and coils for adults 18+. Retail delivery across the UK and trade accounts for vape shops.",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#0d0e12",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en-GB" className={`${GeistSans.variable} ${GeistMono.variable}`}>
      <body className="min-h-dvh font-sans antialiased">
        <StoreProvider>
          {children}
          <AgeGate />
        </StoreProvider>
      </body>
    </html>
  );
}
