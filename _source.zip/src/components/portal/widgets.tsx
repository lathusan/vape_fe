import type { LucideIcon } from "lucide-react";
import { ArrowDownRight, ArrowUpRight } from "lucide-react";
import { Card, cn } from "@/components/ui";

export function StatCard({ label, value, delta, icon: Icon, dark }: { label: string; value: string; delta?: number; icon: LucideIcon; dark?: boolean }) {
  return (
    <Card className={cn("p-4 sm:p-5", dark && "border-ink bg-ink text-white")}>
      <div className="flex items-center justify-between">
        <p className={cn("text-sm", dark ? "text-white/60" : "text-muted")}>{label}</p>
        <span className={cn("grid size-8 place-items-center rounded-lg", dark ? "bg-white/10 text-lime" : "bg-violet-soft text-violet")}><Icon className="size-4" /></span>
      </div>
      <p className="mt-3 text-2xl font-semibold tracking-tight sm:text-[28px]">{value}</p>
      {delta !== undefined && (
        <p className={cn("mt-1 inline-flex items-center gap-0.5 text-xs font-medium", delta >= 0 ? (dark ? "text-lime" : "text-success") : "text-danger")}>
          {delta >= 0 ? <ArrowUpRight className="size-3.5" /> : <ArrowDownRight className="size-3.5" />}
          {Math.abs(delta)}% <span className={cn("font-normal", dark ? "text-white/50" : "text-muted")}>vs last month</span>
        </p>
      )}
    </Card>
  );
}

// Lightweight SVG bar chart: no chart library needed for the mock.
export function BarChart({ data, labels, prefix = "£", accent = "#6d5bff" }: { data: number[]; labels: string[]; prefix?: string; accent?: string }) {
  const max = Math.max(...data) * 1.1;
  const w = 100 / data.length;
  return (
    <div>
      <div className="relative h-52 sm:h-60">
        {[0.25, 0.5, 0.75, 1].map((g) => (
          <div key={g} className="absolute inset-x-0 border-t border-dashed border-line" style={{ bottom: `${g * 100}%` }}>
            <span className="absolute -top-2.5 right-0 bg-white pl-1 text-[10px] text-muted">{prefix}{Math.round((max * g) / 1000)}k</span>
          </div>
        ))}
        <div className="absolute inset-0 flex items-end gap-[3%] pr-8">
          {data.map((v, i) => (
            <div key={i} className="group relative flex h-full flex-1 items-end" style={{ maxWidth: `${w}%` }}>
              <div
                className="w-full rounded-t-md transition-all group-hover:opacity-80"
                style={{ height: `${(v / max) * 100}%`, background: i === data.length - 1 ? accent : `${accent}40` }}
              />
              <span className="pointer-events-none absolute -top-7 left-1/2 hidden -translate-x-1/2 rounded-md bg-ink px-1.5 py-0.5 text-[10px] whitespace-nowrap text-white group-hover:block">
                {prefix}{v.toLocaleString()}
              </span>
            </div>
          ))}
        </div>
      </div>
      <div className="mt-2 flex gap-[3%] pr-8">
        {labels.map((l) => (
          <span key={l} className="flex-1 text-center text-[10px] text-muted sm:text-xs">{l}</span>
        ))}
      </div>
    </div>
  );
}

export function Tabs<T extends string>({ value, onChange, items }: { value: T; onChange: (v: T) => void; items: { id: T; label: string; count?: number }[] }) {
  return (
    <div className="no-scrollbar -mx-4 flex gap-1.5 overflow-x-auto px-4 sm:mx-0 sm:px-0">
      {items.map((t) => (
        <button
          key={t.id}
          onClick={() => onChange(t.id)}
          className={cn("flex h-9 shrink-0 items-center gap-1.5 rounded-full px-3.5 text-sm font-medium transition", value === t.id ? "bg-ink text-white" : "bg-white text-ink/70 hover:text-ink border border-line")}
        >
          {t.label}
          {t.count !== undefined && <span className={cn("rounded-full px-1.5 text-[11px]", value === t.id ? "bg-white/20" : "bg-black/5")}>{t.count}</span>}
        </button>
      ))}
    </div>
  );
}

export const fmtDate = (d: string) => new Date(d).toLocaleDateString("en-GB", { day: "numeric", month: "short" });

// Table on desktop, stacked cards on mobile.
export function Th({ children, className }: { children?: React.ReactNode; className?: string }) {
  return <th className={cn("px-4 py-3 text-left text-xs font-medium uppercase tracking-wider text-muted", className)}>{children}</th>;
}
export function Td({ children, className }: { children?: React.ReactNode; className?: string }) {
  return <td className={cn("px-4 py-3.5 text-sm", className)}>{children}</td>;
}
