"use client";

import Link from "next/link";
import { AlertTriangle, ArrowRight, Banknote, Boxes, FileUp, Package, Plus, ReceiptText, ShieldCheck, ShoppingCart, TrendingUp, Users, Wallet } from "lucide-react";
import { gbp, products, retailOrders, salesSeries, tradeAccounts, tradeOrders } from "@/lib/data";
import { ProductArt } from "@/components/ui/ProductArt";
import { ButtonLink, Card, StatusPill } from "@/components/ui";
import { PageHeader } from "./Shell";
import { BarChart, fmtDate, StatCard } from "./widgets";

function CardHead({ title, href, label = "View all" }: { title: string; href?: string; label?: string }) {
  return (
    <div className="flex items-center justify-between px-5 pt-5">
      <h2 className="font-semibold">{title}</h2>
      {href && <Link href={href} className="text-sm font-medium text-violet">{label}</Link>}
    </div>
  );
}

export function WholesalerDashboard() {
  const lowStock = products.filter((p) => p.stock < 100).slice(0, 4);
  const pending = tradeAccounts.filter((a) => a.status === "pending");
  return (
    <>
      <PageHeader
        title="Good evening, Nishan"
        sub="Here's how your wholesale business is doing this month."
        actions={
          <>
            <ButtonLink href="/wholesaler/price-list" variant="outline" size="sm"><FileUp className="size-4" /> Upload price list</ButtonLink>
            <ButtonLink href="/wholesaler/products/new" size="sm"><Plus className="size-4" /> Add product</ButtonLink>
          </>
        }
      />

      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        <StatCard label="Trade revenue (Nov)" value="£10,420" delta={18} icon={TrendingUp} dark />
        <StatCard label="Open orders" value="3" delta={-4} icon={Package} />
        <StatCard label="Active retailers" value="58" delta={6} icon={Users} />
        <StatCard label="Unpaid invoices" value={gbp(1306)} icon={ReceiptText} />
      </div>

      <div className="mt-4 grid gap-4 xl:grid-cols-3">
        <Card className="xl:col-span-2">
          <CardHead title="Trade sales, last 12 months" href="/wholesaler/reports" label="Reports" />
          <div className="p-5"><BarChart data={salesSeries.wholesale} labels={salesSeries.months} /></div>
        </Card>
        <Card>
          <CardHead title="Low stock" href="/wholesaler/products" />
          <ul className="space-y-3 p-5">
            {lowStock.map((p) => (
              <li key={p.id} className="flex items-center gap-3">
                <ProductArt category={p.category} seed={+p.id.slice(1)} className="size-11 shrink-0 rounded-lg" />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium">{p.name}</p>
                  <p className="text-xs text-muted">{p.sku}</p>
                </div>
                <span className={`text-sm font-semibold ${p.stock === 0 ? "text-danger" : "text-warn"}`}>{p.stock === 0 ? "Out" : `${p.stock} left`}</span>
              </li>
            ))}
          </ul>
        </Card>
      </div>

      <div className="mt-4 grid gap-4 xl:grid-cols-3">
        <Card className="xl:col-span-2">
          <CardHead title="Latest trade orders" href="/wholesaler/orders" />
          <ul className="divide-y divide-line p-2">
            {tradeOrders.slice(0, 5).map((o) => (
              <li key={o.id}>
                <Link href={`/wholesaler/orders/${o.id}`} className="flex items-center gap-3 rounded-xl px-3 py-3 hover:bg-paper">
                  <div className="grid size-10 shrink-0 place-items-center rounded-full bg-violet-soft text-sm font-semibold text-violet">{o.customer[0]}</div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium">{o.customer}</p>
                    <p className="text-xs text-muted">{o.id} · {fmtDate(o.date)} · {o.items.reduce((s, i) => s + i.qty, 0)} units</p>
                  </div>
                  <div className="hidden sm:block"><StatusPill status={o.status} /></div>
                  <p className="w-20 text-right text-sm font-semibold">{gbp(o.total)}</p>
                </Link>
              </li>
            ))}
          </ul>
        </Card>
        <div className="space-y-4">
          <Card className="p-5">
            <div className="flex items-center justify-between">
              <h2 className="font-semibold">Retailer applications</h2>
              <span className="rounded-full bg-lime px-2 text-xs font-bold">{pending.length}</span>
            </div>
            {pending.map((a) => (
              <div key={a.id} className="mt-4 rounded-xl bg-paper p-3">
                <p className="text-sm font-medium">{a.business}</p>
                <p className="text-xs text-muted">{a.city} · VAT {a.vat}</p>
                <div className="mt-3 flex gap-2">
                  <button className="h-8 flex-1 rounded-full bg-ink text-xs font-medium text-white">Approve</button>
                  <Link href="/wholesaler/retailers" className="grid h-8 flex-1 place-items-center rounded-full border border-line bg-white text-xs font-medium">Review</Link>
                </div>
              </div>
            ))}
          </Card>
          <Card className="p-5">
            <h2 className="font-semibold">Top sellers this month</h2>
            <ol className="mt-3 space-y-2.5 text-sm">
              {["Blue Razz Ice 10ml", "Aerolux Flow Pod Kit", "Nic Shot 18mg 10ml", "Aerolux Flow Pods (3 pack)"].map((n, i) => (
                <li key={n} className="flex items-center gap-3"><span className="grid size-6 place-items-center rounded-full bg-black/5 text-xs font-semibold">{i + 1}</span><span className="flex-1 truncate">{n}</span><span className="text-muted">{[1240, 640, 2100, 520][i]} u</span></li>
              ))}
            </ol>
          </Card>
        </div>
      </div>
    </>
  );
}

export function RetailerDashboard() {
  const toFulfil = retailOrders.filter((o) => o.status === "pending" || o.status === "processing");
  const low = products.filter((p) => p.stock < 150).slice(0, 3);
  const acct = tradeAccounts[0];
  return (
    <>
      <PageHeader
        title="Hi Jordan 👋"
        sub="Cloud Nine Vapes · Leeds. Your shop at a glance."
        actions={
          <>
            <ButtonLink href="/retailer/restock" variant="soft" size="sm"><ShoppingCart className="size-4" /> Buy wholesale</ButtonLink>
            <ButtonLink href="/retailer/products/new" size="sm"><Plus className="size-4" /> Add product</ButtonLink>
          </>
        }
      />

      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        <StatCard label="Sales today" value="£482.60" delta={12} icon={TrendingUp} dark />
        <StatCard label="Orders to send" value={String(toFulfil.length)} icon={Package} />
        <StatCard label="Stock value (cost)" value="£14,210" icon={Boxes} />
        <StatCard label="Next payout" value="£1,318.40" icon={Banknote} />
      </div>

      <div className="mt-4 grid gap-4 xl:grid-cols-3">
        <Card className="xl:col-span-2">
          <CardHead title="Shop sales, last 12 months" />
          <div className="p-5"><BarChart data={salesSeries.retail.map((v) => v * 10)} labels={salesSeries.months} accent="#0d0e12" /></div>
        </Card>
        <Card className="p-5">
          <div className="flex items-center justify-between">
            <h2 className="font-semibold">Trade account</h2>
            <span className="rounded-full bg-amber-100 px-2 py-0.5 text-xs font-semibold text-amber-800">{acct.tier}</span>
          </div>
          <p className="mt-4 text-sm text-muted">Credit used</p>
          <p className="text-2xl font-semibold">{gbp(acct.balance)} <span className="text-sm font-normal text-muted">of {gbp(acct.creditLimit)}</span></p>
          <div className="mt-3 h-2 overflow-hidden rounded-full bg-black/5">
            <div className="h-full rounded-full bg-violet" style={{ width: `${(acct.balance / acct.creditLimit) * 100}%` }} />
          </div>
          <div className="mt-5 rounded-xl bg-paper p-3 text-sm">
            <p className="flex justify-between"><span className="text-muted">Next invoice due</span><b>6 Dec</b></p>
            <p className="mt-1 flex justify-between"><span className="text-muted">Amount</span><b>{gbp(868)}</b></p>
          </div>
          <ButtonLink href="/retailer/purchases" variant="outline" size="sm" className="mt-4 w-full">View purchase orders</ButtonLink>
        </Card>
      </div>

      <div className="mt-4 grid gap-4 xl:grid-cols-3">
        <Card className="xl:col-span-2">
          <CardHead title="Orders to send" href="/retailer/orders" />
          <ul className="divide-y divide-line p-2">
            {retailOrders.slice(0, 5).map((o) => (
              <li key={o.id}>
                <Link href={`/retailer/orders/${o.id.replace("#", "")}`} className="flex items-center gap-3 rounded-xl px-3 py-3 hover:bg-paper">
                  <div className="grid size-10 shrink-0 place-items-center rounded-full bg-lime/60 text-sm font-semibold">{o.customer[0]}</div>
                  <div className="min-w-0 flex-1">
                    <p className="flex items-center gap-1.5 truncate text-sm font-medium">{o.customer} {o.ageVerified && <ShieldCheck className="size-3.5 text-success" />}</p>
                    <p className="text-xs text-muted">{o.id} · {fmtDate(o.date)} · {o.method}</p>
                  </div>
                  <div className="hidden sm:block"><StatusPill status={o.status} /></div>
                  <p className="w-16 text-right text-sm font-semibold">{gbp(o.total)}</p>
                </Link>
              </li>
            ))}
          </ul>
        </Card>
        <Card className="p-5">
          <h2 className="flex items-center gap-2 font-semibold"><AlertTriangle className="size-4 text-warn" /> Running low</h2>
          <ul className="mt-4 space-y-3">
            {low.map((p) => (
              <li key={p.id} className="flex items-center gap-3">
                <ProductArt category={p.category} seed={+p.id.slice(1)} className="size-11 shrink-0 rounded-lg" />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium">{p.name}</p>
                  <p className="text-xs text-muted">{Math.round(p.stock / 20)} in shop · trade {gbp(p.tiers[0].price)}</p>
                </div>
              </li>
            ))}
          </ul>
          <ButtonLink href="/retailer/restock" size="sm" className="mt-5 w-full">Restock now <ArrowRight className="size-4" /></ButtonLink>
          <div className="mt-4 flex items-center gap-3 rounded-xl bg-violet-soft p-3 text-sm text-violet">
            <Wallet className="size-5" /> Payouts every Friday to Barclays •• 2201
          </div>
        </Card>
      </div>
    </>
  );
}

