"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { Bell, ExternalLink, LogOut, Menu, MoreHorizontal, Search, X } from "lucide-react";
import { portals, type PortalRole } from "@/lib/portal";
import { useStore } from "@/lib/store";
import { cn } from "@/components/ui";

export function PortalShell({ role, children }: { role: PortalRole; children: React.ReactNode }) {
  const cfg = portals[role];
  const path = usePathname();
  const router = useRouter();
  const { setRole } = useStore();
  const [drawer, setDrawer] = useState(false);

  useEffect(() => setRole(role), [role, setRole]);
  useEffect(() => setDrawer(false), [path]);

  const isActive = (href: string) => {
    const full = cfg.base + href;
    return href === "" ? path === cfg.base : path.startsWith(full);
  };

  const logout = () => {
    setRole("guest");
    router.push("/");
  };

  const NavList = (
    <nav className="space-y-0.5">
      {cfg.nav.map((n) => (
        <Link
          key={n.href}
          href={cfg.base + n.href}
          className={cn(
            "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition",
            isActive(n.href) ? "bg-white/10 text-white" : "text-white/60 hover:bg-white/5 hover:text-white",
          )}
        >
          <n.icon className={cn("size-[18px]", isActive(n.href) && "text-lime")} />
          <span className="flex-1">{n.label}</span>
          {n.badge && <span className="rounded-full bg-lime px-1.5 text-[11px] font-bold text-ink">{n.badge}</span>}
        </Link>
      ))}
    </nav>
  );

  const Brand = (
    <div className="flex items-center gap-2.5">
      <span className="grid size-9 place-items-center rounded-xl bg-lime font-bold text-ink">N</span>
      <div className="leading-tight">
        <p className="font-semibold text-white">Nimbus</p>
        <p className="text-[11px] uppercase tracking-wider text-lime">{cfg.title} portal</p>
      </div>
    </div>
  );

  const Profile = (
    <div className="rounded-2xl bg-white/5 p-3">
      <div className="flex items-center gap-3">
        <div className="grid size-9 place-items-center rounded-full bg-violet text-sm font-semibold text-white">{cfg.initials}</div>
        <div className="min-w-0 flex-1 leading-tight">
          <p className="truncate text-sm font-medium text-white">{cfg.business}</p>
          <p className="truncate text-xs text-white/50">{cfg.plan}</p>
        </div>
        <button onClick={logout} className="text-white/50 hover:text-white" aria-label="Log out"><LogOut className="size-4" /></button>
      </div>
    </div>
  );

  const mobileTabs = cfg.nav.filter((n) => n.mobile).slice(0, 4);

  return (
    <div className="min-h-dvh bg-paper lg:pl-64">
      {/* Desktop sidebar */}
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 flex-col gap-6 bg-ink p-4 lg:flex">
        <div className="px-2 pt-2">{Brand}</div>
        <div className="flex-1 overflow-y-auto">{NavList}</div>
        <Link href="/" className="flex items-center gap-2 px-3 text-sm text-white/50 hover:text-white"><ExternalLink className="size-4" /> View website</Link>
        {Profile}
      </aside>

      {/* Top bar */}
      <header className="sticky top-0 z-20 border-b border-line bg-paper/85 backdrop-blur-xl">
        <div className="flex h-16 items-center gap-3 px-4 sm:px-6 lg:px-8">
          <button onClick={() => setDrawer(true)} className="-ml-2 grid size-10 place-items-center rounded-full hover:bg-black/5 lg:hidden" aria-label="Menu"><Menu className="size-5" /></button>
          <p className="font-semibold lg:hidden">{cfg.business}</p>
          <label className="hidden h-10 max-w-md flex-1 items-center gap-2 rounded-full border border-line bg-white px-4 md:flex">
            <Search className="size-4 text-muted" />
            <input placeholder={role === "wholesaler" ? "Search products, orders, retailers…" : "Search orders, products, customers…"} className="w-full bg-transparent text-sm outline-none" />
            <kbd className="rounded border border-line px-1.5 text-[10px] text-muted">⌘K</kbd>
          </label>
          <div className="ml-auto flex items-center gap-1">
            <button className="relative grid size-10 place-items-center rounded-full hover:bg-black/5" aria-label="Notifications">
              <Bell className="size-5" />
              <span className="absolute right-2.5 top-2.5 size-2 rounded-full bg-danger" />
            </button>
            <div className="ml-1 hidden items-center gap-2 sm:flex">
              <div className="grid size-9 place-items-center rounded-full bg-violet text-sm font-semibold text-white">{cfg.initials}</div>
              <div className="hidden leading-tight xl:block">
                <p className="text-sm font-medium">{cfg.user}</p>
                <p className="text-xs text-muted">Owner</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="px-4 pb-28 pt-6 sm:px-6 lg:px-8 lg:pb-12">{children}</main>

      {/* Mobile drawer */}
      {drawer && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-ink/60" onClick={() => setDrawer(false)} />
          <aside className="animate-slide-in absolute inset-y-0 left-0 flex w-[82%] max-w-xs flex-col gap-6 bg-ink p-4">
            <div className="flex items-center justify-between px-2 pt-2">
              {Brand}
              <button onClick={() => setDrawer(false)} className="grid size-9 place-items-center rounded-full text-white/70 hover:bg-white/10" aria-label="Close"><X className="size-5" /></button>
            </div>
            <div className="flex-1 overflow-y-auto">{NavList}</div>
            <Link href="/" className="flex items-center gap-2 px-3 text-sm text-white/50"><ExternalLink className="size-4" /> View website</Link>
            {Profile}
          </aside>
        </div>
      )}

      {/* Mobile bottom tabs */}
      <nav className="pb-safe fixed inset-x-0 bottom-0 z-30 border-t border-line bg-white/95 backdrop-blur-xl lg:hidden">
        <div className="grid grid-cols-5 pt-1.5">
          {mobileTabs.map((n) => (
            <Link key={n.href} href={cfg.base + n.href} className={cn("relative flex flex-col items-center gap-0.5 py-1 text-[11px] font-medium", isActive(n.href) ? "text-ink" : "text-muted")}>
              <n.icon className={cn("size-[22px]", isActive(n.href) && "stroke-[2.4]")} />
              <span className="max-w-full truncate px-1">{n.short ?? n.label}</span>
              {n.badge && <span className="absolute right-[24%] top-0 grid min-w-4 place-items-center rounded-full bg-danger px-1 text-[10px] font-bold text-white">{n.badge}</span>}
            </Link>
          ))}
          <button onClick={() => setDrawer(true)} className="flex flex-col items-center gap-0.5 py-1 text-[11px] font-medium text-muted">
            <MoreHorizontal className="size-[22px]" />
            More
          </button>
        </div>
      </nav>
    </div>
  );
}

export function PageHeader({ title, sub, actions, back }: { title: string; sub?: string; actions?: React.ReactNode; back?: { href: string; label: string } }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
      <div className="min-w-0">
        {back && <Link href={back.href} className="mb-1 inline-block text-sm text-muted hover:text-ink">← {back.label}</Link>}
        <h1 className="text-2xl font-semibold tracking-tight sm:text-3xl">{title}</h1>
        {sub && <p className="mt-1 text-sm text-muted">{sub}</p>}
      </div>
      {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
    </div>
  );
}
